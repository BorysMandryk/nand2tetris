This game allows the player to move a snake using arrow keys.
The snake has to eat food to increase its length.
The goal of the game is to get the longest snake possible.
The score represents how much food was eaten.
To start the game player has to press any arrow key.
The game is over if the snake bumps into a wall or itself.
To restart the game after it is over player needs to press the 'space' key.
To quit the game player can press the 'q' key.
Notice: input from the keyboard may sometimes not be read due to calls to the Sys.wait function between frames