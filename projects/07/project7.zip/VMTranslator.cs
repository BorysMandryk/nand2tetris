﻿using System;
using System.IO;

namespace VMTranslator
{
    internal class VMTranslator
    {
        static void Main(string[] args)
        {
            const string baseDir = @"D:\nand2tetris\projects\07";
            //string[] files = Directory.GetFiles(baseDir, "*.vm", SearchOption.AllDirectories);
            //foreach (string f in files)
            //{
            //    Console.WriteLine(f);
            //    TranslateFile(f);
            //}
            TranslateFile(args[0]);
            //TranslateFile(Path.Combine(baseDir, args[0]));
        }

        static void TranslateFile(string path)
        {
            // В нових версіях можна просто 
            // using Parser parser = new Parser;...
            using (Parser parser = new Parser(path))
            using (CodeWriter codeWriter = new CodeWriter(ChangeFileExtension(path, "asm")))
            {
                while (parser.HasMoreCommands())
                {
                    parser.Advance();
                    CommandType commandType = parser.GetCommandType();
                    string arg1;
                    int arg2;
                    switch (commandType)
                    {
                        case CommandType.C_ARITHMETIC:
                            arg1 = parser.Arg1();
                            codeWriter.WriteArithmetic(arg1);
                            break;
                        case CommandType.C_PUSH:
                            arg1 = parser.Arg1();
                            arg2 = parser.Arg2();
                            codeWriter.WritePush(arg1, arg2);
                            break;
                        case CommandType.C_POP:
                            arg1 = parser.Arg1();
                            arg2 = parser.Arg2();
                            codeWriter.WritePop(arg1, arg2);
                            break;
                        case CommandType.C_LABEL:
                            break;
                        case CommandType.C_GOTO:
                            break;
                        case CommandType.C_IF:
                            break;
                        case CommandType.C_FUNCTION:
                            break;
                        case CommandType.C_RETURN:
                            break;
                        case CommandType.C_CALL:
                            break;
                        default:
                            break;
                    }

                }
            }
        }

        static string ChangeFileExtension(string filename, string newExtension)
        {
            int index = filename.LastIndexOf('.');
            return filename.Substring(0, index + 1) + newExtension;
        }
    }
}