﻿using System;
using System.IO;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.Intrinsics.X86;
using System.Text;
using System.Threading.Tasks;

namespace VMTranslator
{
    internal class CodeWriter : IDisposable
    {
        private StreamWriter _streamWriter;
        private string _path;

        private int _eqCnt;
        private int _gtCnt;
        private int _ltCnt;

        private bool _disposed = false;

        public CodeWriter(string path)
        {
            _streamWriter = new StreamWriter(path);
            _path = path;
        }

        public void WriteArithmetic(string command)
        {
            switch (command)
            {
                case "add":
                    WriteAdd();
                    break;
                case "sub":
                    WriteSub();
                    break;
                case "neg":
                    WriteNeg();
                    break;
                case "eq":
                    WriteEq();
                    break;
                case "gt":
                    WriteGt();
                    break;
                case "lt":
                    WriteLt();
                    break;
                case "and":
                    WriteAnd();
                    break;
                case "or":
                    WriteOr();
                    break;
                case "not":
                    WriteNot();
                    break;
                default:
                    throw new ArgumentException("Unknown command");
            }
            _streamWriter.WriteLine(_streamWriter.NewLine);
        }

        public void WritePush(string segment, int index)
        {
            string str = $@"// push {segment} {index}
";
            switch(segment)
            {
                case "local":
                    str += $@"@LCL
D=M
@{index}
A=D+A
D=M";
                    break;
                case "argument":
                    str += $@"@ARG
D=M
@{index}
A=D+A
D=M";
                    break;
                case "this":
                    str += $@"@THIS
D=M
@{index}
A=D+A
D=M";
                    break;
                case "that":
                    str += $@"@THAT
D=M
@{index}
A=D+A
D=M";
                    break;
                case "constant":
                    str += $@"@{index}
D=A";
                    break;
                case "static":
                    str += $@"@{Path.GetFileNameWithoutExtension(_path)}.{index}
D=M";
                    break;
                case "temp":
                    str += $@"@5
D=A
@{index}
A=D+A
D=M";
                    break;
                case "pointer":
                    if(index == 0)
                    {
                        str += $@"@THIS
D=M";
                    }
                    else if (index == 1)
                    {
                        str += $@"@THAT
D=M";
                    }
                    else
                    {
                        throw new ArgumentException("Index for pointer must be 0 or 1");
                    }
                    break;
                default:
                    throw new ArgumentException("Unknown command");
            }
            str += $@"
@SP
A=M
M=D
@SP
M=M+1";
            _streamWriter.Write(str);
            _streamWriter.WriteLine(_streamWriter.NewLine);
        }

        public void WritePop(string segment, int index)
        {
            string str = $@"// pop {segment} {index}
@SP
AM=M-1
D=M
";
            switch (segment)
            {
                case "local":
                    str += $@"@LCL
D=D+M
@{index}
D=D+A
@SP
A=M
A=M
A=D-A
M=D-A";
                    break;
                case "argument":
                    str += $@"@ARG
D=D+M
@{index}
D=D+A
@SP
A=M
A=M
A=D-A
M=D-A";
                    break;
                case "this":
                    str += $@"@THIS
D=D+M
@{index}
D=D+A
@SP
A=M
A=M
A=D-A
M=D-A";
                    break;
                case "that":
                    str += $@"@THAT
D=D+M
@{index}
D=D+A
@SP
A=M
A=M
A=D-A
M=D-A";
                    break;
                case "constant":
                    throw new InvalidOperationException("Unsupported command for constant");
                    break;
                case "static":
                    str += $@"@{Path.GetFileNameWithoutExtension(_path)}.{index}
M=D";
                    break;
                case "temp":
                    str += $@"@5
D=D+A
@{index}
D=D+A
@SP
A=M
A=M
A=D-A
M=D-A";
                    break;
                case "pointer":
                    if (index == 0)
                    {
                        str += $@"@THIS
M=D";
                    }
                    else if (index == 1)
                    {
                        str += $@"@THAT
M=D";
                    }
                    else
                    {
                        throw new ArgumentException("Index for pointer must be 0 or 1");
                    }
                    break;
                default:
                    throw new ArgumentException("Unknown command");
            }

            _streamWriter.Write(str);
            _streamWriter.WriteLine(_streamWriter.NewLine);
        }

        private void WriteAdd()
        {
            string str = @"// add
@SP
AM=M-1
D=M
A=A-1
M=M+D";
            _streamWriter.Write(str);
        }

        private void WriteSub()
        {
            string str = @"// sub
@SP
AM=M-1
D=M
A=A-1
M=M-D";
            _streamWriter.Write(str);
        }

        private void WriteNeg()
        {
            string str = @"// neg
@SP
A=M-1
M=-M";
            _streamWriter.Write(str);
        }

        private void WriteEq()
        {
            string str = $@"// eq
@SP
AM=M-1
D=M
A=A-1
D=M-D
@EQUAL_{_eqCnt}
D;JEQ
@SP
A=M-1
M=0
@EQ_END_{_eqCnt}
0;JMP
(EQUAL_{_eqCnt})
@SP
A=M-1
M=-1
(EQ_END_{_eqCnt})";
            _eqCnt++;
            _streamWriter.Write(str);
        }

        private void WriteGt()
        {
            string str = $@"// gt
@SP
AM=M-1
D=M
A=A-1
D=M-D
@GREATER_{_gtCnt}
D;JGT
@SP
A=M-1
M=0
@GT_END_{_gtCnt}
0;JMP
(GREATER_{_gtCnt})
@SP
A=M-1
M=-1
(GT_END_{_gtCnt})";
            _gtCnt++;
            _streamWriter.Write(str);
        }

        private void WriteLt()
        {
            string str = $@"// lt
@SP
AM=M-1
D=M
A=A-1
D=M-D
@LESS_{_ltCnt}
D;JLT
@SP
A=M-1
M=0
@LT_END_{_ltCnt}
0;JMP
(LESS_{_ltCnt})
@SP
A=M-1
M=-1
(LT_END_{_ltCnt})";
            _ltCnt++;
            _streamWriter.Write(str);
        }

        private void WriteAnd()
        {
            string str = @"// and
@SP
AM=M-1
D=M
A=A-1
M=M&D";
            _streamWriter.Write(str);
        }

        private void WriteOr()
        {
            string str = @"// or
@SP
AM=M-1
D=M
A=A-1
M=M|D";
            _streamWriter.Write(str);
        }

        private void WriteNot()
        {
            string str = @"// not
@SP
A=M-1
M=!M";
            _streamWriter.Write(str);
        }

        public void Dispose()
        {
            Dispose(true);
            GC.SuppressFinalize(this);
        }

        private void Dispose(bool disposing)
        {
            if(_disposed)
            {
                return;
            }

            if(disposing)
            {
                _streamWriter.Close();
            }

            _disposed = true;
        }

        ~CodeWriter()
        {
            Dispose(false);
        }
    }
}
