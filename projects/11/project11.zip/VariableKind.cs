﻿namespace JackCompiler
{
    public enum VariableKind
    {
        NONE,
        STATIC,
        FIELD,
        ARG,
        VAR
    }
}