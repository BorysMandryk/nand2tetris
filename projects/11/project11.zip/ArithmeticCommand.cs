﻿namespace JackCompiler
{
    public enum ArithmeticCommand
    {
        ADD,
        SUB,
        NEG,
        EQ,
        GT,
        LT,
        AND,
        OR,
        NOT
    }
}